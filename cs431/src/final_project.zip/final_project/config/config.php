<?php


$server = 'localhost';
$username = '';
$password = '';
$db = 'nurse';


define("DB_SERVER",$server);
define("DB_USER",$username);
define("DB_PASS",$password);
define("DB_NAME",$db);

