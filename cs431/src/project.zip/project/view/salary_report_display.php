<?php require_once ('navbar.php') ?>
<meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0">

<br><br><center>To be updated ...</center>