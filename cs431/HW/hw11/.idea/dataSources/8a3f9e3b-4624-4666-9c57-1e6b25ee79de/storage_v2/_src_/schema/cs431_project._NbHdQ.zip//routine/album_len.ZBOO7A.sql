CREATE FUNCTION album_len(s INT)
  RETURNS VARCHAR(16)
  BEGIN
            DECLARE hours, minutes, seconds INT;
            SET hours = s DIV 3600;
            SET minutes = (s MOD 3600) DIV 60;
            SET seconds = s MOD 60;
            IF hours > 0 THEN
                RETURN CONCAT_WS(':', hours, LPAD(minutes, 2, '0'), LPAD(seconds, 2, '0' ));
            ELSE
                RETURN CONCAT_WS(':', minutes, LPAD(seconds, 2, '0' ));
            END IF;
        END;

