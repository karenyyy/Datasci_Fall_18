
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script src="../js/functions.js"></script>


<?php
/**
 * Created by PhpStorm.
 * User: karen
 * Date: 11/14/18
 * Time: 4:41 PM
 */


require_once('../connect/connect.php');
require_once('../helper/schedulehelper.php');


function check_available($con)
{
    if (isset($_POST["date"],
              $_POST['emptype'])) {
        $date = $_POST['date'];
        $emptype = $_POST['emptype'];

        $query = "
            select empid, emptype
                from employees2
                where emptype='$emptype'
                and empid not in
                    (select empid from (select table2.empid, table2.date from (select empid
                                                            from employees2
                                                            where emptype='$emptype') as table1
                                                             inner join
                                                               (select *
                                                                from daysoff) as table2
                                                               on table1.empid = table2.empid
                     where date = '$date') as request_day_off)
                and empid not in
                    (select empid from (select table2.empid, table2.date from (select empid
                                                            from employees2
                                                            where emptype='$emptype') as table1
                                                             inner join
                                                               (select *
                                                                from schedule2) as table2
                                                               on table1.empid = table2.empid
                     where date = '$date') as already_scheduled)
        ";

        if (!($result = mysqli_query($con, $query))) {
            $msg = 'MySQL error #' . mysqli_connect_errno() . ": " . mysqli_connect_error();

            printf($msg, __FILE__, __LINE__);

        } else if (0 == mysqli_num_rows($result)) {
            echo "<center><h3>There're no $emptype employees available on $date!</h3></center><br>";
            return "";
        } else {
            echo "<br><br>";
            echo "<center><h4>The available list of $emptype employees on $date</h4><br><br>";
            echo "<table class='table table-striped' border=1>";
            echo "<tr>";
            $i = 0;
            $col_name = array();
            while ($i < mysqli_num_fields($result)) {
                $meta = mysqli_fetch_field_direct($result, $i);
                echo '<td>' . $meta->name . '</td>';
                $i = $i + 1;
                array_push($col_name, $meta->name);
            }
            echo '<td>Date</td>';
            echo '<td>Department</td>';
            echo '<td>Shift</td>';
            echo '<td>Schedule</td>';


            while ($row = mysqli_fetch_assoc($result)) {
                echo "<tr>\n";
                $index = 0;
                echo "<form class='post_form' action='../tasks/add_schedule.php' method='post'>";
                foreach ($row as $cell) {
                    echo "<td><input style='width: 100px' type='text' name='$col_name[$index]' value='$cell'></td>";
                    $index++;
                }
                echo "<td><input style='width: 100px' type='text' name='date' value='$date'></td>";
                echo '<td><select name=\'dept\'>'.DepartmentNeedList($con).'</select></td>';
                echo '<td><select name=\'shift\'>'.ShiftList($con).'</select></td>';
                echo "<td><input type='submit' value='schedule'></td>";
                echo "</tr></form>\n";
            }

            echo "</table><br><br><br>";
        }
    }
}


check_available($con);