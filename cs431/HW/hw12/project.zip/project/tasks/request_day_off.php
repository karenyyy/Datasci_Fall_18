<?php
/**
 * Created by PhpStorm.
 * User: karen
 * Date: 10/24/18
 * Time: 6:25 PM
 */

require_once('../connect/connect.php');

function request_day_off($con)
{
    if (isset($_POST['request_empid'], $_POST['request_date'])) {
        $empid = $_POST['request_empid'];
        $date = $_POST['request_date'];
        $date = convert_date_format($date);

        $query = "SELECT firstname, lastname
                  FROM employees
                  WHERE empid = '$empid'";
        $result = mysqli_query($con, $query);
        $row = mysqli_fetch_assoc($result);
        $firstname = $row['firstname'];
        $lastname = $row['lastname'];

        $query = "SELECT *
                FROM schedule
                WHERE empid='$empid'
                AND date='$date'";
        if (0 == mysqli_num_rows(mysqli_query($con, $query))) {

            $query = "SELECT *
                FROM dayoff
                WHERE empid='$empid'
                AND date='$date'";
            if (0 != mysqli_num_rows(mysqli_query($con, $query))) {
                echo '<br><h4><center><i>' . $firstname . ' ' . $lastname . '</i> (id: ' . $empid . ') has already requested the day off on ' . $date . ' </center></h4><br>';
            } else {
                echo '<br><h4><center><i>' . $firstname . ' ' . $lastname . '</i> (id: ' . $empid . ') is able to request a day off on ' . $date . ' </center></h4><br>';

                $request = "INSERT INTO dayoff (empid, date) VALUES ('$empid', '$date')";
                $result = mysqli_query($con, $request);
                if (!($result)) {
                    $msg = 'MySQL error #' . mysqli_connect_errno() . ": " . mysqli_connect_error();
                    printf($msg, __FILE__, __LINE__);
                } else {
                    echo "<center><h3>$date off for $firstname $lastname (id: $empid) successfully requested!</h3></center>";
                }
            }

        } else {
            echo '<br><h4><center><i>' . $firstname . ' ' . $lastname . '</i> (id: ' . $empid . ') has already been scheduled and is not able to request a day off on ' . $date . '  </center></h4><br>';

            $query = "SELECT *
                FROM schedule
                WHERE empid='$empid'
                AND date='$date'";

            $result = mysqli_query($con, $query);

            echo "<table class='table table-striped' border=1>";
            echo "<tr>";
            $i = 0;
            while ($i < mysqli_num_fields($result)) {
                $meta = mysqli_fetch_field_direct($result, $i);
                echo '<td>' . $meta->name . '</td>';
                $i = $i + 1;
            }

            while ($row = mysqli_fetch_assoc($result)) {
                echo "<tr>\n";
                foreach ($row as $cell) {
                    echo "<td> $cell </td>";
                }
                echo "</tr>\n";
            }

            echo "</table><br><br><br>";
        }
    }
}

request_day_off($con);