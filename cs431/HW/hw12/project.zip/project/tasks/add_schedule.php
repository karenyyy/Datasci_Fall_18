<?php
/**
 * Created by PhpStorm.
 * User: karen
 * Date: 11/14/18
 * Time: 7:31 PM
 */
require_once('../view/navbar.php');
require_once('../connect/connect.php');
require_once('../helper/schedulehelper.php');


function delete_from_needs($con)
{
    if (isset(
        $_POST['empid'],
        $_POST["date"],
        $_POST['emptype'],
        $_POST['dept'],
        $_POST['shift'])) {

        $dept = $_POST['dept'];
        $date = $_POST['date'];
        $shift = $_POST['shift'];
        $emptype = $_POST['emptype'];

        $query = "
            update department_need
            set number_of_employees = number_of_employees - 1
            where emptype='$emptype'
            and date='$date'
            and period='$shift'
            and department_name='$dept'
        ";
        $result = mysqli_query($con, $query);
        if (!($result)) {
            $msg = 'MySQL error #' . mysqli_connect_errno() . ": " . mysqli_connect_error();
            printf($msg, __FILE__, __LINE__);
        } else {
            echo '<br><br><h3><center>The number of employees needed for department ' . $dept . ' is updated.</center></h3><br><br>';
        }

        $query = "
            select number_of_employees
                from department_need
                where emptype='$emptype'
                  and date='$date'
                  and period='$shift'
                  and department_name='$dept'
        ";

        $result = mysqli_query($con, $query);
        if (!($result)) {
            $msg = 'MySQL error #' . mysqli_connect_errno() . ": " . mysqli_connect_error();
            printf($msg, __FILE__, __LINE__);
        } else {
            $num_emp = mysqli_fetch_assoc($result);

            if ($num_emp['number_of_employees'] == 0) {
                $query = "
                delete from department_need
                    where emptype='$emptype'
                      and date='$date'
                      and period='$shift'
                      and department_name='$dept'
                  ";
                $result = mysqli_query($con, $query);
                if (!($result)) {
                    $msg = 'MySQL error #' . mysqli_connect_errno() . ": " . mysqli_connect_error();
                    printf($msg, __FILE__, __LINE__);
                }
            }
        }

    }
}


function schedule_by_emptype($con)
{
    if (isset(
        $_POST['empid'],
        $_POST["date"],
        $_POST['emptype'],
        $_POST['dept'],
        $_POST['shift'])) {

        $emptype = $_POST['emptype'];
        $empid = $_POST['empid'];
        $dept = $_POST['dept'];
        $date = $_POST['date'];
        $shift = $_POST['shift'];

        $query = "
            select *
                from department_need
                where emptype='$emptype'
                  and date='$date'
                  and period='$shift'
                  and department_name='$dept'
        ";
        $result = mysqli_query($con, $query);
        if (!($result)) {
            $msg = 'MySQL error #' . mysqli_connect_errno() . ": " . mysqli_connect_error();
            printf($msg, __FILE__, __LINE__);
        } else {
            if (0 == mysqli_num_rows($result)) {
                echo '<br><br><h3><center>No ' . $emptype . ' employees are needed for department ' . $dept . ' from ' . $shift . ' on ' . $date . '.</center></h3><br><br>';
            } else {
                $query = "
                    insert into schedule2 (dept, date, shift, empid)
                    values ('$dept', '$date', '$shift', $empid);
                ";

                $result = mysqli_query($con, $query);
                if (!($result)) {
                    $msg = 'MySQL error #' . mysqli_connect_errno() . ": " . mysqli_connect_error();
                    printf($msg, __FILE__, __LINE__);
                } else {
                    $query = "
                      SELECT firstname, lastname
                      FROM employees2
                      WHERE empid = '$empid'
                      ";
                    $result = mysqli_query($con, $query);
                    $row = mysqli_fetch_assoc($result);
                    $firstname = $row['firstname'];
                    $lastname = $row['lastname'];
                    echo '<br><br><h3><center><i>' . $firstname . ' ' . $lastname . '</i> (id: ' . $empid . ') is successfully scheduled
                for department ' . $dept . ' from ' . $shift . ' on date ' . $date . '</center></h3><br><br>';
                }

                delete_from_needs($con);
            }
        }
    }
}

schedule_by_emptype($con);

?>

<script>
    setTimeout(function () {
        window.location.href = '../view/schedule_emptype_display.php';
    }, 5000);
</script>