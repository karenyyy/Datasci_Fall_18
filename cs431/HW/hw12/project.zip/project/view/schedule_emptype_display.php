<?php require_once('../helper/schedulehelper.php'); ?>
<?php require_once('navbar.php') ?>

    <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0">

    <div style="margin-top: 3%">
        <h2>
            <center> Schedule available employees</center>
        </h2>
        <br>

        <form class="post_form" action="" method="post">
            <br>
            Date:
            <select name="date">
                <?php echo DateList($con) ?>
            </select><br><br>


            Employee Type:
            <select name="emptype">
                <?php echo EmptypeList($con) ?>
            </select><br><br>

            <input class="check_button" type="submit" value="Check">

        </form>
        <br><br>
    </div>


<?php require_once('../tasks/schedule_by_emptype.php'); ?>