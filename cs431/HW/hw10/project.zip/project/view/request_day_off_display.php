<?php require_once ('navbar.php') ?>

<?php require_once('../helper/schedulehelper.php'); ?>

    <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0">

    <div style="margin-top: 3%">
        <h2>
            <center> Request A Day Off </center>
        </h2>
        <br>

        <form class="post_form" action="" method="post">
            <br>
            EmployeeID: <input type="text" name="request_empid"><br><br>

            Request Date: <input type="text" name="request_date"> (format: 'mm-dd-yy')<br><br>

            <input class="check_button" type="submit" value="Request">

        </form>
        <br><br>
    </div>

<?php require_once('../tasks/request_day_off.php'); ?>