<?php require_once ('navbar.php') ;
      require_once ('../connect/connect.php');
?>

<meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0">

<?php
$query = "
    SELECT DEPARTMENT,
          EMPLOYEE_TYPE,
  CONCAT(DATE_FORMAT(START_TIME, '%I%p'),
         '-',
         DATE_FORMAT(END_TIME, '%I%p')) AS SHIFT,
  CONCAT('$', SUM(EACH_COST)) AS COST FROM
  (SELECT s.dept AS DEPARTMENT, e.empid as EMPLOYEEID,
          IF(LENGTH(e.emptype)=0, 'NA', e.emptype) AS EMPLOYEE_TYPE,
          s.start_time AS START_TIME, s.shift_length AS SHIFT_LEN, sh.end_time AS END_TIME,
          IF(s.start_time>'16:00:00' OR (s.start_time>'12:00:00' AND s.shift_length=12),
             ROUND(s.shift_length*e.wage_per_hrs*1.2, 3), ROUND((s.shift_length*e.wage_per_hrs), 3)) AS EACH_COST
   FROM schedule AS s, employees AS e, shift AS sh
   WHERE s.empid = e.empid
   AND s.start_time=sh.from_time
   AND s.shift_length = sh.length
   ORDER BY s.start_time) AS tmp
GROUP BY DEPARTMENT, EMPLOYEE_TYPE, SHIFT
ORDER BY DEPARTMENT, EMPLOYEE_TYPE, START_TIME, END_TIME;
";

//$query = "
//   SELECT DEPARTMENT,
//  EMPLOYEE_TYPE,
//  CONCAT(DATE_FORMAT(START_TIME, '%I%p'),
//         '-',
//         DATE_FORMAT(DATE_ADD(START_TIME, INTERVAL SHIFT_LEN HOUR), '%I%p')) AS SHIFT,
//  CONCAT(SUM(EACH_COST)) AS COST FROM
//  (SELECT s.dept AS DEPARTMENT,
//           IF(LENGTH(e.emptype)=0, 'NA', e.emptype) AS EMPLOYEE_TYPE,
//           s.start_time AS START_TIME, s.shift_length AS SHIFT_LEN,
//           IF(s.start_time>'16:00:00' OR (s.start_time>'12:00:00' AND s.shift_length=12),
//              ROUND(s.shift_length*e.wage_per_hrs*1.2, 3), ROUND((s.shift_length*e.wage_per_hrs), 3)) AS EACH_COST
//    FROM schedule AS s, employees AS e
//    WHERE s.empid = e.empid
//    ORDER BY s.start_time) AS tmp
//GROUP BY DEPARTMENT, EMPLOYEE_TYPE, SHIFT
//ORDER BY DEPARTMENT, EMPLOYEE_TYPE, START_TIME, DATE_ADD(START_TIME, INTERVAL SHIFT_LEN HOUR);
//";

$result = mysqli_query($con, $query);

echo "<center><h2>Salary Report</h2></center>";
echo "<br><table class='table table-striped' border=1>";
echo "<tr>";
$i = 0;
while ($i < mysqli_num_fields($result)) {
    $meta = mysqli_fetch_field_direct($result, $i);
    echo '<td>' . $meta->name . '</td>';
    $i = $i + 1;
}

while ($row = mysqli_fetch_assoc($result)) {
    echo "<tr>\n";
    foreach ($row as $cell) {
        echo "<td> $cell </td>";
    }
    echo "</tr>\n";
}

echo "</table><br><br><br>";